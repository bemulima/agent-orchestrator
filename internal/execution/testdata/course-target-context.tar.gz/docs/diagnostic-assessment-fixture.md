# V2 diagnostic assessment fixture

Course owns the versioned `diagnostic_assessment_smoke` fixture in
`internal/usecase/diagnosticfixture/fixture.v1.json`. It is independent from
the V0 `course_catalog_smoke` fixture and has the fixed slug
`diagnostic-assessment-smoke-v1`.

The fixture provisions one active and catalog-visible Course hierarchy:

```text
Course → Module → Section → Lesson → three ordered Task assessments
```

Every Task is active, has type `test`, purpose `diagnostic`, and uses the exact
capability contract `NO_RUN` / `AUTO` / `QUIZ` / `ANSWER_PAYLOAD`. Each has a
stable source key, one opaque Course learning target, one localized
single-choice question, and three localized variants. Course owns the trusted
answer key. It is never emitted by the provisioning result or diagnostic
catalog response.

## Fresh migration command

Before fixture provisioning, apply the versioned forward Course migrations to
a new, empty Course database:

```bash
mc-course-service migrate-fresh
# or, from a source checkout:
task migrate-fresh
```

The command discovers only `db/migrations/*.sql` forward migrations in lexical
filename order and skips `*.down.sql`. It never imports `db/seeds`. It checks
that the target public schema has no tables before applying the first file,
stops on the first SQL error, and exits nonzero on every failure. The final
machine-readable line follows `course-migration-result.v1` and contains only a
status, a safe reason, count, and failed migration basename when applicable.

The service image includes `db/migrations`, so Infrastructure can invoke the
same command inside the pinned Course image. `COURSE_MIGRATIONS_DIR` may point
to an alternate mounted migration directory for a reviewed owner workflow.

## Provision command

After a successful fresh migration, Infrastructure invokes:

```bash
LW_V2_COURSE_FIXTURE_RUN_ID=<isolated-run-id> \
LW_V2_COURSE_FIXTURE_TARGET_DATABASE=<the-database-selected-for-that-run> \
mc-course-service provision-diagnostic-assessment-fixture
```

The command requires both guards. The run ID must be a short opaque identifier
containing only letters, digits, `.`, `_`, or `-`. The target database value
must exactly equal PostgreSQL `current_database()`. No Docker volume name is
embedded in Course source, so Infrastructure can use a distinct Compose
project and volume on every run.

An absent fixture is created transactionally. An exact fixture is read back
without writes and returns `already_present`. Any slug, identity, hierarchy,
capability, translation, learning target, question, variant, reference, or
catalog projection drift returns a nonzero failure. The command never starts
NATS, connects to an AI provider, or enables a service feature flag.

Success is a single `course-diagnostic-assessment-fixture-result.v1` JSON
object containing the fixture identity, Course ID/slug, active/catalog flags,
observed diagnostic `curriculum_revision`, and ordered answer-key-free task
metadata. Failed results contain only the schema, `failed` status, and a safe
reason; they do not include database URLs, credentials, answer keys, task
questions, variants, or the run ID.
