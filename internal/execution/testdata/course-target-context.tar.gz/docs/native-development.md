# Native macOS development

Course runs as a macOS process while Docker retains the shared NATS broker and
the existing isolated Course PostgreSQL server. D8 does not move Course data
into `platform-postgres` and does not run Course migrations against its
meaningful existing database.

## Start dependencies

From `learning-platform-infrastructure`:

```sh
make native-infra-up
make native-infra-check
```

The existing Course PostgreSQL server is published loopback-only at
`127.0.0.1:15432`; this is the same `lw-course-db` volume and database used by
the Docker Course service.

## Run Course natively

```sh
task native-status
task run:native
```

The native adapter reads the approved infrastructure dotenv at
`../../learning-platform-infrastructure/.env` by default (override with
`LW_INFRA_ENV_FILE`). It derives credentials without printing them and supplies:

| Dependency | Native value |
| --- | --- |
| Course PostgreSQL | `127.0.0.1:15432/lw_course` as `lw` |
| NATS | `nats://127.0.0.1:4222` |
| HTTP listener | `127.0.0.1:18083` |
| Student task-progress service | `http://127.0.0.1:18084` |
| FileStorage | `http://127.0.0.1:18085` |

`COURSE_NATIVE_*` variables provide explicit local overrides. The optional
`HTTP_HOST` configuration preserves the existing Docker default (`:HTTP_PORT`)
and lets only the native task bind loopback.

## Migration safety

`task native-status` is read-only and records the connected Course schema. Do
not run the historical `migrate-up` task against `lw_course`: it has no durable
migration ledger and suppresses SQL failures, while historical files contain
destructive transformations. D8 uses the current existing-safe schema without a
Course migration. A reviewed Course-owner backup and forward-only migration plan
is required before changing this database.

## Docker Compose path

`task up` retains the standalone named `pgdata` volume. Compose now supplies
its own NATS broker and maps application HTTP only when `COURSE_HTTP_PORT` is
set. Use a project-specific port for local parity checks; never run `task down`
because that legacy command removes volumes.
