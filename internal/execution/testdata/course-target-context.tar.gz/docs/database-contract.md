# Database contract

PostgreSQL is the source of truth for authored catalog, content hierarchy, task definitions, import tracking, and FileStorage bindings. Schema history lives in ordered files under `db/migrations`; repository queries and migrations must change together.

Major groups are catalog/reference tables and translations, ordered hierarchy relations, content and semantic relations, task/assessment tables, compose and code-structure metadata, and `course_seed_import` ownership tracking.

Stable `source_key` values identify managed imported content. Ordered relation rows define placement of reusable entities and must remain deterministic. Assessment children must match the parent task type; task starter rows reference objects owned by FileStorage. `task_learning_target` stores only ordered opaque concept/capability references; student evidence and mastery never belong in this schema.

`generated_course` stores immutable Course planning provenance and enforces
unique `(origin, fingerprint_version, course_fingerprint)`. `generated_lesson`
stores structured targets, prerequisites, transition knowledge, and exact
pedagogy strategy versions for the ordinary Lesson row. `generated_course_request`
provides request-body idempotency. These metadata tables do not add a node to
the Course → Module → Section → Lesson hierarchy. Learning Planner sends only a
fully generated payload; the same transaction creates active private hierarchy
rows, examples, knowledge-check tasks, target references, and provenance, so
there is no externally visible partially built Course.
The same tables store lazily requested practice prerequisite material with
`fingerprint_version=practice-material-fingerprint-v1`; it is represented as a
complete one-Lesson private Course rather than a new hierarchy level.

## Migration rules

- Inspect all historical migrations and current repository queries before altering an existing table.
- Prefer additive, reversible, data-preserving changes with explicit backfills and constraints.
- Update seeds, import validation, readback verification, and contracts when identifiers or required references change.
- `mc-course-service migrate-fresh` (and `task migrate-fresh`) is the Course-owned fresh-database migration command. It applies only forward files in lexical order, rejects a nonempty public schema, imports no seed data, stops on the first failure, returns a safe JSON result, and exits nonzero on every error.
- Never run `task migrate-down` without explicit destructive authorization; it drops and recreates the entire public schema.

Migration 053 adds `lesson_completion_policy` and `lesson_revision`. Revisions
contain immutable trusted content plus completion definitions, are deduplicated
by `(lesson_id, content_hash)`, and reject UPDATE/DELETE through a database
trigger. Resolution reads a repeatable-read transaction, so concurrent author
changes cannot yield a mixed snapshot. IDs are deterministically derived from
the complete definition hash; assessment keys contribute to that hash.
No rows are synthesized during migration: legacy assignment history is not
fabricated. Policy updates only influence subsequently resolved revisions.

`generated_course_revision_receipt` freezes revision bindings returned for each
generated request idempotency key; request replay after Course edits returns
the originally selected revisions. It is populated only when a cutover receipt
is first resolved and does not claim to reconstruct legacy assignments.
