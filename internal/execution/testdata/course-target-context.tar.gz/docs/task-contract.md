# Authored task contract

Course owns task definitions; student attempts and validator/sandbox execution are downstream concerns. A task combines localized content, its lesson placement, ordered status, a task type, capability fields, code structure, optional runtime configuration and starter files.

## Learning targets

A task may carry up to 100 ordered `learning_targets`. Each target is an opaque
reference with `type=concept|capability`, a stable lowercase `key`, and an
optional `version`. Course persists and returns these authored references but
does not interpret prerequisites, graph semantics, evidence, confidence, or
mastery.

The internal task response returns `learning_targets`. Legacy tasks may return
no targets. Consumers must not derive targets from task titles, descriptions,
source-key segments, validator stages, or code structure. The existing
`task.version` field is not the target version and must not be used as one.

The internal course-structure projection includes the same targets on each
task plus lesson/task `updated_at` values and a deterministic `sha256:`
`curriculum_revision` over the ordered payload. Teacher may use that revision
for auditable path planning, but Course still does not own diagnostics,
mastery, or any student's path.

## Types and capabilities

Supported types are `frontend_preview`, `fullstack_page`, `cli_programming`, `api_endpoint`, `debug_fix`, `refactor_quality`, `git_cli`, `sql_query`, `quiz_theory`, `practice_task_milestone`, `test`, `ordering`, and `classification`.

Capabilities use explicit execution (`BROWSER_PREVIEW`, `TERMINAL_RUN`, `HTTP_API`, `NO_RUN`), evaluation (`AUTO`, `MANUAL`, `HYBRID`), UI (`PREVIEW`, `TERMINAL`, `REPORT`, `QUIZ`), and submission (`SNAPSHOT`, `ANSWER_PAYLOAD`) modes plus sandbox, preview, terminal, and live-validation flags. Defaults may be inferred from type or a recognized versioned validation contract; explicit values are validated against incompatible combinations.

A sandbox task must resolve compose configuration from the task or parent lesson. A versioned contract cannot advertise PHP core live validation when all `php.core` stages are submit-only.

## Coding tasks

Coding tasks require translations, a code-structure type, non-empty `code_structure`, and a nonnegative order. They reject assessment questions and normalize `allowed_errors_count` to zero. `code_structure` may be legacy data or a recognized ValidationContractV1; versioned contracts are validated for workspace, stages, links, engines, modes, and dependency/link integrity by the domain code.

## Assessments

`test`, `ordering`, and `classification` store questions in `task_test` tables. The server selects the matching service code-structure type, writes a canonical assessment `code_structure`, and clears compose configuration.

Each assessment has `assessment_purpose=knowledge_check|diagnostic`. Existing
rows are backfilled to `knowledge_check`; diagnostic content must opt in
explicitly at authoring time and is never inferred from task type or title.
The purpose is exposed on admin and trusted internal task reads; the public
task response remains unchanged for strict legacy clients.
`GET /internal/course/get-internal-diagnostic-assessments/{courseID}` returns a
`course-diagnostic-assessment-catalog.v1` bounded, deterministic,
answer-key-free catalog for Planner selection. It includes each task's numeric
`version` and `updated_at`; `curriculum_revision` covers the ordered active
lesson/task/target projection. Only active diagnostic assessment tasks under
active lessons are returned, and each must use the exact uppercase
`evaluation_mode=AUTO`; a diagnostic task with `MANUAL`, `HYBRID`, or an
invalid mode fails the catalog read with a validation error. Course status is
not independently rechecked by this projection; callers must select an exact
active Course.

Public task responses never expose answer keys. They omit correctness/order/group
fields from structured-test variants and recursively remove
`expected_answers` from text-quiz `code_structure`; the authenticated internal
task endpoint retains those fields for trusted evaluation consumers.

The V2 `diagnostic_assessment_smoke` fixture is a Course-owned, versioned
three-task structured diagnostic catalog. Its provisioning result and the
Planner diagnostic-catalog projection contain task metadata and opaque learning
targets only; they never contain question text, variants, answer keys, or
student answer payloads. See [V2 diagnostic assessment fixture](diagnostic-assessment-fixture.md).

Every assessment has at least one localized question, unique positive question and variant orders, 2–50 variants, and `0 <= allowed_errors_count < question count`.

- `test` uses single choice, at most five variants, and exactly one correct answer.
- `ordering` requires every variant to have a unique target position from 1 through the number of variants.
- `classification` requires 2–20 localized groups, every variant to resolve exactly one group, and every group to be used.

The detailed transport/storage rules are in [Structured assessment contract](structured-assessment-contract.md).

## State and change safety

An active task cannot change type. A task cannot be deactivated while its parent lesson remains active. Repository deletion is a hard delete, so callers must evaluate downstream usage and compatibility before removing authored tasks.

Task contract changes require coordinated checks of Course handlers/domain, database migrations, seed/import validation, student consumers, validator engines, and sandbox/runtime behavior.
