# Go service architecture template

This document is the reusable structural reference for Learning Platform Go
services. `ms-go-course` is the executable reference: its architecture policy
and tests are authoritative when this template and an implementation differ.

The application layer is named `internal/usecase`. Do not introduce an
`internal/application` duplicate.

## Layout

Create only directories required by the service's real inbound protocols and
outbound dependencies. Empty protocol or infrastructure directories are not a
requirement.

```text
cmd/<service>/main.go                 # composition root only
internal/
├── domain/                           # entities, value objects, rules, ports
├── usecase/                          # application orchestration and use cases
├── transport/                        # inbound adapters
│   ├── http/
│   │   ├── router.go                 # root HTTP composition
│   │   ├── api/v1/handlers/          # public API handlers and their DTOs
│   │   ├── admin/v1/handlers/        # admin handlers and their DTOs
│   │   └── private/handlers/         # internal handlers and their DTOs
│   ├── message/nats/                 # only when the service consumes messages
│   ├── websocket/                    # only when the service accepts WebSockets
│   └── cli/                          # only when the service exposes a CLI
└── infrastructure/                   # outbound adapters
    ├── persistence/postgres/         # only when PostgreSQL is used
    ├── messaging/nats/               # only when the service publishes messages
    ├── http/<remote-service>/         # concrete outbound HTTP clients
    └── <technical-adapter>/          # filesystem, provider, runtime, cache, etc.
```

The `api`, `admin`, and `private` contours are optional. When a contour exists,
keep its router, handlers, DTOs, parsing, mapping, and middleware inside that
contour. Do not add a shared top-level `handler`, `dto`, `middleware`, or
`adapters` package merely for convenience.

## Dependency rules

```text
transport ─────→ usecase ─────→ domain
                     ↑
                     │
infrastructure ──────┘
```

- `domain` has no dependency on transport, infrastructure, frameworks, HTTP,
  databases, messaging clients, or provider SDKs.
- `usecase` may depend on domain and inner-layer contracts, but not on concrete
  HTTP, persistence, messaging, framework, or provider implementations.
- `transport` parses inbound data, applies transport validation, maps DTOs,
  invokes a use case, maps the result, and selects a protocol response. It does
  not contain business rules, SQL, persistence access, or orchestration.
- `infrastructure` contains concrete outbound implementations only. Inner
  layers refer to those capabilities through ports owned by the inner layer
  that needs them.
- `cmd/<service>/main.go` is the only composition root. It constructs concrete
  adapters and injects them into use cases and inbound transport.
- `internal/adapters` is forbidden. Replace it with the explicit inbound
  `transport` or outbound `infrastructure` owner.

## Safe migration procedure

1. Characterize existing routes, JSON DTOs, status codes, message subjects,
   configuration, and externally visible errors with current tests.
2. Move inbound code to `internal/transport` without changing route paths,
   payloads, middleware order, authentication semantics, or status codes.
3. Extract framework, SQL, driver, HTTP-client, filesystem, provider, and
   messaging code from domain/usecase into `internal/infrastructure` behind
   existing or newly introduced inner-layer ports.
4. Move only dependency wiring to the command entrypoint. Keep use-case method
   signatures and business decisions stable unless a separate approved task
   requires a behavioral change.
5. Add a fail-closed architecture policy for the actual service layout, then
   run it with formatting, vet, tests, and build checks.

Architecture work must not alter business logic, database schema, migrations,
environment compatibility, HTTP contracts, or inter-service event contracts.
