# Lesson reading access

`lesson_read_access` controls who may read a lesson body. It is independent of
catalog visibility, entity lifecycle status, progression, tasks, tests, and
sandbox execution.

The optional field is available on track, level, course group, course, module,
section, and lesson create/update APIs. Supported explicit values are:

- `guest`: everyone;
- `student`: authenticated `STUDENT` and `STUDENT_PRO` users;
- `student_pro`: authenticated `STUDENT_PRO` users;
- `disabled`: no student-facing audience.

`null` means inherit. The nearest explicit value on the active placement path
wins:

```text
lesson -> section -> module -> course -> course group -> level -> track
```

If no node configures a value, the effective value is `student`. This keeps
existing and newly imported lessons readable by authenticated students.
`ADMIN`, `MODERATOR`, and `TEACHER` bypass the student-facing policy.

Reusable content may have more than one active placement. The most permissive
effective placement that is valid for the current navigation path is used.
An exact semantic relation can make a hidden active course reachable, but it
does not bypass `lesson_read_access`.

Update semantics are intentionally import-safe:

- omitted field: keep the existing value;
- explicit `null`: clear the local override and inherit;
- explicit value: replace the local override.

Public lesson lists include `effective_read_access` and `can_read`. When
`can_read` is false, full Markdown/translations and runtime configuration are
not returned. A denied lesson body returns a stable JSON error code:

- `lesson_authentication_required` (`401`);
- `lesson_pro_required` (`403`);
- `lesson_reading_disabled` (`403`);
- `lesson_reading_forbidden` (`403`).
