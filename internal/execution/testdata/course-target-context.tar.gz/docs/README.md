# Course service documentation

Repository code, migrations, tests, and these documents are the source of truth for Course behavior. Machine-readable summaries live under `.ai/contracts`; update both forms when a contract changes.

## Architecture and interfaces

- [Architecture](architecture.md) — ownership, layers, dependencies, and trust boundaries.
- [Go service architecture template](go-service-architecture-template.md) — reusable Clean Architecture reference for other platform Go services.
- Canonical architecture/policy verification: `./scripts/check-agent-policy.sh` (defined by `.ai/commands.yaml`).
- [HTTP contract](http-contract.md) — route surfaces, authentication, authorization, and compatibility.
- [Task contract](task-contract.md) — task types, capabilities, validation structures, and assessments.
- [Database contract](database-contract.md) — schema groups, identity, hierarchy, and migration safety.
- [Messaging contract](messaging-contract.md) — lifecycle subjects, payloads, and delivery limits.

## Detailed product contracts

- [Knowledge task manifest](knowledge-task-manifest.md) — deprecated offline compatibility importer; not part of Practice v2.
- [Lesson read access](lesson-read-access.md) — inherited audience policy and response semantics.
- [Structured assessment contract](structured-assessment-contract.md) — assessment request/storage details.
- [V2 diagnostic assessment fixture](diagnostic-assessment-fixture.md) — isolated diagnostic catalog, fresh migration, and guarded provisioning commands.

`README.md` remains the operational guide and endpoint catalog. Exact routes are registered in `internal/transport/http`; exact schema history is in `db/migrations`.
