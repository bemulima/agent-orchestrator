# Messaging contract

Course publishes six best-effort NATS JetStream lifecycle subjects:

| Subject | Payload keys |
| --- | --- |
| `course.created` | `course_id`, `slug` |
| `course.updated` | `course_id`, `slug` |
| `course.deleted` | `course_id`, `slug` |
| `task.created` | `task_id`, `lesson_id` |
| `task.updated` | `task_id` |
| `task.deleted` | `task_id`, `lesson_id` |

Normal use cases publish after successful persistence. The knowledge-import transaction registers publication for after commit, preventing events from a rolled-back database batch.

Delivery is not guaranteed: service startup ignores NATS connection errors, a nil connection makes the publisher a no-op, and use cases discard publish errors. Consumers must not treat these events as the only source of truth. Guaranteed delivery requires a separate outbox/retry design.

Changing subjects or payloads requires an inventory of consumers, a compatibility plan, producer tests, and synchronized documentation.
