# Structured assessment contract

`ms-go-course` owns the authored definition of single-choice, ordering, and
classification assessments. It stores and returns that definition without
converting structured activities into single-choice questions. Rendering,
answer persistence, scoring, attempts, and progress remain owned by
`ms-go-student`.

Assessment purpose is an explicit authored discriminator: `knowledge_check` or
`diagnostic`. Legacy and omitted values resolve to `knowledge_check`; only an
explicit `diagnostic` authoring value opts a task into Planner diagnostic
discovery.

## Task and question kinds

| `task_kind` | Question `kind` | Code structure type |
| --- | --- | --- |
| `test` | `single_choice` | `TEST_SINGLE_CHOICE_BASIC` |
| `ordering` | `ordering` | `TEST_ORDERING_BASIC` |
| `classification` | `classification` | `TEST_CLASSIFICATION_BASIC` |

All three task kinds use `NO_RUN`, `AUTO`, `QUIZ`, `ANSWER_PAYLOAD`, and no
sandbox. One task may contain multiple questions, but every question kind must
match its task kind.

## Authoring invariants

- Questions, groups, and variants have stable UUIDs and optional stable
  `source_key` values. Knowledge manifests require the keys and derive the UUIDs
  deterministically.
- Question and display orders are positive and unique within their parent.
- Single-choice questions contain 2–5 variants and exactly one
  `is_correct: true` variant.
- Ordering questions contain 2–50 variants. Every variant has one unique
  `correct_order`, and the values form the contiguous range `1..N`.
- Classification questions contain 2–20 localized groups and 2–50 variants.
  Every variant references a group, and every declared group receives at least
  one variant.
- `allowed_errors_count` is non-negative and lower than the number of
  questions.

Create and update are atomic: replacing an assessment either writes the whole
question/group/item graph or leaves the previous graph intact.

## Trusted read contract

Admin `GET /task/get/{taskID}` and internal
`GET /internal/task/get-internal-task/{taskID}` return answer keys. The internal
route requires `X-Internal-Token`.

An ordering question includes the authored display order and the canonical
answer order independently:

```json
{
  "kind": "ordering",
  "variants": [
    {
      "id": "<stable-variant-uuid>",
      "source_key": "course.lesson.task.question.item-a",
      "order": 1,
      "correct_order": 2,
      "translations": []
    }
  ]
}
```

A classification question exposes localized group definitions and trusted
variant assignments:

```json
{
  "kind": "classification",
  "groups": [
    {
      "id": "<stable-group-uuid>",
      "source_key": "course.lesson.task.question.group-a",
      "order": 1,
      "translations": []
    }
  ],
  "variants": [
    {
      "id": "<stable-variant-uuid>",
      "source_key": "course.lesson.task.question.item-a",
      "order": 1,
      "group_id": "<stable-group-uuid>",
      "group_source_key": "course.lesson.task.question.group-a",
      "translations": []
    }
  ]
}
```

`ms-go-student` should compare submitted identities, not localized text or
array positions. For ordering, compare the submitted variant-ID sequence with
variants sorted by `correct_order`. For classification, compare each submitted
variant/group UUID pair with `group_id`. `source_key` supports reconciliation
and diagnostics; UUID is the runtime identity.

## Public read boundary

`GET /api/v1/task/get/{taskID}` returns the question prompts, variants, display
orders, and classification group labels required to render an activity. It
omits all answer fields:

- `is_correct`;
- `correct_order`;
- `group_id`;
- `group_source_key`.

Public clients must never infer correctness from the authoring order. The
initial display order may intentionally differ from the canonical ordering.

## Answer payload ownership

This service does not accept or persist student answers. A downstream answer
payload must retain the task, question, variant, and (for classification)
group UUIDs so it can be evaluated against a trusted internal read. Adding or
changing a student-facing submission endpoint belongs to `ms-go-student` and
must preserve these identities rather than copying answer keys into a public
response.
