# Architecture

`ms-go-course` owns canonical learning content: catalog references, reusable hierarchy entities and placements, authored or Learning Planner-generated lesson material, examples and relations, task definitions, structured assessments, compose/runtime metadata, starter-file bindings, and legacy knowledge-import identity retained only for existing managed content. Learning Planner may request an idempotent generated Course through its dedicated private command, including a single-lesson private Course materialized lazily for one frozen practice-route target, but Course alone persists and serves the resulting complete active content. Practice v2 never invokes the deprecated Knowledge Tree importer.

Course does not own the student-specific practice route. A lazy practice material remains an ordinary `Course -> Module -> Section -> Lesson` hierarchy, is deduplicated by `practice-material-fingerprint-v1`, and becomes visible only after its complete content, checks, exact target binding, and provenance commit atomically.

It does not own student answers, attempts, reviews, progress, validator execution, sandbox lifecycle, or FileStorage objects. It consumes student progress through an internal client and references FileStorage objects for task starters.

Course also exposes a bounded internal current-content projection for exact
selected-text verification by Teacher. The projection uses `lesson.updated_at`
as a current revision marker; it is not immutable content history. Course owns
the canonical text, while Teacher keeps it transient and sends only the
verified student-selected substring to prompt execution.

## Layers

- `internal/domain` defines content entities, task contracts, repository ports, errors, and event subjects.
- `internal/usecase` owns catalog/hierarchy rules, visibility, task normalization, imports, and lifecycle orchestration.
- `internal/transport/http` exposes inbound admin, public, and internal transports.
- `internal/infrastructure/persistence/postgres` implements persistence; migrations own schema history.
- `internal/infrastructure/messaging/nats` publishes lifecycle events through JetStream.
- `internal/infrastructure/filestorage` calls FileStorage; `internal/infrastructure/http/taskanswer` calls the student service's internal task-progress endpoint. Concrete outbound HTTP clients belong to infrastructure, never transport or adapters.
- `cmd/mc-course-service` is the composition root.

The authoritative executable architecture and agent-policy check is `./scripts/check-agent-policy.sh`, defined once as `commands.policy` in `.ai/commands.yaml`. It is read-only, invokes the fail-closed architecture scanner, and must pass before and after edits. Agents, reviewers, and CI must use this command rather than copying scanner invocations.

## Core invariants

The authored navigation chain is track -> level -> course group -> course -> module -> section -> lesson -> task. Modules, sections, and lessons are reusable; ordered relation rows define placement and must not be collapsed into entity ownership.

Public reads require valid active navigation and then apply inherited lesson read access. Administrative reads allow `TEACHER`, `ADMIN`, and `MODERATOR`; mutations allow only `ADMIN` and `MODERATOR`.

Task type, capability fields, `code_structure`, assessment children, compose configuration, and starter-file bindings form a cross-service contract. See [Task contract](task-contract.md).

The deprecated knowledge-import compatibility path uses stable source keys and deterministic IDs. It exists only for legacy managed Course migration and is not a dependency of current authoring/runtime. Database operations are prepared and applied in a server-side transaction; lifecycle events are deferred until commit. Starter archive upload happens after the database batch and has its own binding/activation compensation behavior, so it is not one distributed transaction.

## Trust boundaries and known limitations

Admin identity is read from `X-User-ID` and `X-User-Role`; the service assumes a trusted gateway removed spoofed headers. Internal routes use a shared `X-Internal-Token`. Defaults named `change-me` are development conveniences and must not reach a real environment.

NATS connection failure does not stop startup, a nil connection turns publication into a no-op, and current use cases ignore publish errors. Events are therefore best-effort, not a transactional outbox.
