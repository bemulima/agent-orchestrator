# Anonymous catalog verification fixture

Course owns the versioned `course_catalog_smoke` fixture in
`internal/usecase/verificationfixture/fixture.v1.json`. It contains one active,
catalog-visible Course, one active course-only Module, one active Section, one
active guest-readable Lesson, and one active `quiz_theory` Task. The Task uses
`NO_RUN` and does not use a sandbox. Course requires an active Task before it
allows a Lesson to become active, so this single Task is part of the minimum
valid Course aggregate.

The fixture has stable entity IDs. Provisioning is explicit and
transactional. An absent fixture is created and checked through Course use
cases; an exact existing fixture is verified without changing it; any drift at
the canonical slug or deterministic entity IDs fails with a fixture-drift
error. The only shared reference rows it may ensure are the `en` and `ru`
language references and the Course-owned `QUIZ_TEXT_BASIC` structure type. It
does not seed application data at service startup.

Infrastructure owns choosing the target environment and invoking the Course
command. For the V0 local verification runtime use
`make provision-v0-course-fixture` from `learning-platform-infrastructure`.
That command requires the `learning-workspace-local` Course, Gateway, and
Course PostgreSQL containers to be running, proves the mounted
`learning-workspace-local_lw-course-db` volume, compiles the current Course
working tree as a temporary standalone utility, and runs the utility in the
existing Course container. It does not rebuild or restart the service image.

The Course command additionally requires the explicit
`LW_V0_COURSE_FIXTURE_TARGET_VOLUME=learning-workspace-local_lw-course-db`
guard and verifies `current_database() = 'lw_course'`. It returns a compact JSON
result only after the transaction commits and the Course public outline confirms
that the lesson is guest-readable.
