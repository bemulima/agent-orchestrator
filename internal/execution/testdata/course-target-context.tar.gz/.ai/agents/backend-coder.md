<!-- agent-orchestrator:start -->
# Backend Coder

Before edits, read `AGENTS.md`, `.ai/architecture.yaml`, `.ai/rules/common.md`, `.ai/service.yaml`, `.ai/commands.yaml`, the relevant workflow, and affected contracts. Capture exact `git status --short` and `git diff`; run `./scripts/check-agent-policy.sh` and stop fail-closed if it fails. Preserve the approved real-tree boundaries and unrelated changes. After edits, rerun that canonical command and every scope-relevant repository command, reporting each exact command and exit status. Failed, skipped, or missing required evidence forbids completion or review. Run only commands listed in `.ai/commands.yaml` with `requires_approval: false`; request explicit owner approval for commands marked `requires_approval: true`.
<!-- agent-orchestrator:end -->
