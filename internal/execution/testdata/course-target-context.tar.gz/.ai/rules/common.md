# Common Agent Rules

These rules are shared delivery policy. Repository-local business, architecture, contract, and command rules take precedence when they are stricter.

## Source of truth and task state

- Read the current issue, `AGENTS.md`, `.ai/architecture.yaml`, `.ai/rules/common.md`, `.ai/service.yaml`, `.ai/commands.yaml`, the relevant workflow, and affected contracts before changing code.
- Before edits, capture exact `git status --short` and `git diff`, then run the single canonical architecture/policy command `./scripts/check-agent-policy.sh`. Stop fail-closed on any baseline failure.
- Use the issue and its linked plan or pull/merge request as the durable task record. Do not create a parallel journal inside another repository.
- Derive runtime facts from code, manifests, migrations, and versioned contracts. Never invent endpoints, commands, dependencies, or behavior from a prompt.
- Keep canonical business rules, contracts, runbooks, and architecture decisions in the repository that owns them.

## Coding

- Follow existing project boundaries and naming. Prefer the smallest change that satisfies the acceptance criteria.
- Do not introduce a new framework, abstraction, dependency, or directory layout without repository evidence and a concrete need.
- Keep secrets out of source, logs, fixtures, prompts, and examples. Use placeholders in documented configuration.
- Use repository-local `.cache` for disposable tool output when the project has no stricter cache rule.
- Treat transport layout as fail-closed. `internal/transport` permits only `http`, `message`, `cli`, `websocket`, and `common`; do not create empty protocol directories.
- Under `internal/transport/http`, permit only `api`, `admin`, and `private` directories plus root composition Go files. Never create shared `handlers`, `handler`, `dto`, `parsers`, `mapper`, or `middleware` directories.
- Keep public handlers under `api/v1/handlers`, admin handlers under `admin/v1/handlers`, and unversioned private handlers under `private/handlers`. Routers may import only their contour's handlers and genuinely shared HTTP primitives.
- Keep audience-specific DTOs, parsers, mappers, and middleware in their contour. Common transport packages must not contain endpoints or business, persistence, client, or audience-specific logic.
- Treat `internal/infrastructure` as outbound-only and fail-closed to the real paths `persistence/postgres`, `messaging/nats`, `http/taskanswer`, and `filestorage`. `internal/adapters` must be absent.
- Domain and use cases must not import transport, infrastructure, or framework implementations. Root composition must independently wire the three HTTP contours and all outbound implementations.

## Bugfix

- Reproduce or characterize the failure before changing behavior.
- Identify the root cause and affected contract or invariant; do not stop at masking the symptom.
- Add or update a regression test that fails before the fix when practical.
- Run the narrowest relevant checks first, then the repository verification required for handoff.

## Feature

- Confirm acceptance criteria, write scope, affected services, and compatibility requirements before implementation.
- Update tests and owned documentation in the same change when behavior, configuration, or a contract changes.
- For cross-repository work, split ownership by repository and make dependencies explicit in issues; do not copy canonical contracts between repositories.

## Refactor

- State the behavior that must remain unchanged and establish a passing baseline.
- Keep behavior changes separate from structural cleanup unless the issue explicitly combines them.
- Preserve public contracts, migrations, and configuration compatibility, or document and approve the breaking change.

## Review

- Review the real diff independently, with findings before summary.
- Prioritize correctness, security, data integrity, compatibility, migration reversibility, missing tests, and scope violations.
- Cite exact files and lines. Do not edit the implementation during review unless the owner asks for a fix.

## Git, issue, and pull/merge request delivery

- Use one issue, repository, worktree, branch, and agent thread per independently deliverable task.
- Inspect status and diff before committing. Preserve unrelated user changes and never rewrite shared history.
- Keep commits focused and use the repository's commit convention; use Conventional Commits only when no stricter convention exists.
- A pull/merge request must link its issue, describe scope and risk, list verification, and call out contracts, migrations, configuration, and follow-up work.
- Do not push, publish an issue or pull/merge request, merge, deploy, or perform destructive Git operations without the required owner authorization.

## Commands, tests, migrations, and contracts

- Run only commands discovered in `.ai/commands.yaml` or documented by the repository. Request approval for commands marked `requires_approval: true`.
- Treat migrations and contracts as versioned interfaces. Prefer reversible, data-preserving migrations and explicit compatibility checks.
- Verify producers and consumers before changing shared HTTP, event, database, file, or environment contracts.
- After edits, rerun `./scripts/check-agent-policy.sh` and all scope-relevant commands declared in `.ai/commands.yaml`. Report every exact command and exit status; never claim completion or request review while required evidence is failed, skipped, or missing.
