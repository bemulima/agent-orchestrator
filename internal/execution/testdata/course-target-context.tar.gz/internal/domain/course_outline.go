package domain

// CourseOutline is the lightweight, ordered student-facing structure of one
// visible course. It deliberately excludes lesson bodies and task payloads.
type CourseOutline struct {
	CourseID string                `json:"course_id"`
	Slug     string                `json:"slug"`
	Title    string                `json:"title"`
	Modules  []CourseOutlineModule `json:"modules"`
}

// CourseOutlineModule is one authored module placement inside a course.
type CourseOutlineModule struct {
	ID       string                 `json:"id"`
	Title    string                 `json:"title"`
	Order    int                    `json:"order"`
	Sections []CourseOutlineSection `json:"sections"`
}

// CourseOutlineSection is one authored section placement inside a module.
type CourseOutlineSection struct {
	ID      string                `json:"id"`
	Title   string                `json:"title"`
	Order   int                   `json:"order"`
	Lessons []CourseOutlineLesson `json:"lessons"`
}

// CourseOutlineLesson is lightweight lesson navigation metadata for one
// authored section placement.
type CourseOutlineLesson struct {
	ID                  string           `json:"id"`
	Title               string           `json:"title"`
	Order               int              `json:"order"`
	TasksCount          int              `json:"tasks_count"`
	EffectiveReadAccess LessonReadAccess `json:"effective_read_access"`
	CanRead             bool             `json:"can_read"`
}
